<?php

define( 'WEB_PAGE_TO_ROOT', '' );
require_once WEB_PAGE_TO_ROOT.'bhratach/includes/Page.inc.php';

PageStartup( array( 'phpids' ) );

$page = PageNewGrab();
$page[ 'title' ] .= $page[ 'title_separator' ].'Setup';
$page[ 'page_id' ] = 'setup';

if( isset( $_POST[ 'create_db' ] ) ) {

	if ($DBMS == 'MySQL') {
		include_once WEB_PAGE_TO_ROOT.'bhratach/includes/DBMS/MySQL.php';
	}
	elseif ($DBMS == 'PGSQL') {
		include_once WEB_PAGE_TO_ROOT.'bhratach/includes/DBMS/PGSQL.php';
	}
	else {
		MessagePush( "ERROR: Invalid database selected. Please review the config file syntax." );
		PageReload();
	}

}


$page[ 'body' ] .= "
<div class=\"body_padded\">
	<h1>Database setup <img src=\"".WEB_PAGE_TO_ROOT."bhratach/images/spanner.png\"></h1>

	<p>Click on the 'Create / Reset Database' button below to create or reset your database. If you get an error make sure you have the correct user credentials in /config/config.inc.php</p>

	<p>If the database already exists, it will be cleared and the data will be reset.</p>

	<br />

	Backend Database: <b>".$DBMS."</b>

	<br /><br /><br />
	
	<!-- Create db button -->
	<form action=\"#\" method=\"post\">
		<input name=\"create_db\" type=\"submit\" value=\"Create / Reset Database\">
	</form>
</div>
";


HtmlEcho( $page );

?>
