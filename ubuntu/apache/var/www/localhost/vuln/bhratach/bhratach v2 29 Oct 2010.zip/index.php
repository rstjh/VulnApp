<?php

define( 'WEB_PAGE_TO_ROOT', '' );

require_once WEB_PAGE_TO_ROOT.'bhratach/includes/Page.inc.php';

PageStartup( array( 'authenticated', 'phpids' ) );

$page = PageNewGrab();

$page[ 'title' ] .= $page[ 'title_separator' ].'Welcome';

$page[ 'page_id' ] = 'home';

$page[ 'body' ] .= "

<div class=\"body_padded\">

	<h1> Welcome to the Extranet Site for Bhratach.</h1>
	

	<p>This site provides access to core Bhratach information that is available to Bhratach's clients. It is intended to make sharing our information with our business partners, suppliers, key customers, etc, for exchanging data and applications and sharing information.</p>

		<h2> WARNING! </h2>

		<p>Access to this site is only permitted to authorised users.</p>

</div>";


HtmlEcho( $page );

?>
