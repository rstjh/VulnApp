<?php

define( 'WEB_PAGE_TO_ROOT', '../../' );
require_once WEB_PAGE_TO_ROOT.'bhratach/includes/Page.inc.php';

PageStartup( array( 'authenticated', 'phpids' ) );

$page = PageNewGrab();
$page[ 'title' ] .= $page[ 'title_separator' ].'What is your name?';
$page[ 'page_id' ] = 'name';

DatabaseConnect();

$vulnerabilityFile = '';
switch( $_COOKIE[ 'security' ] ) {
	case 'low':
		$vulnerabilityFile = 'low.php';
		break;

	case 'medium':
		$vulnerabilityFile = 'low.php';
		break;

	case 'high':
	default:
		$vulnerabilityFile = 'low.php';
		break;
}

require_once WEB_PAGE_TO_ROOT."flag/name/source/{$vulnerabilityFile}";

$page[ 'body' ] .= "
<div class=\"body_padded\">
	<h1> Enter your name to verify your status? </h1>

	<div class=\"vulnerable_code_area\">

		<form name=\"XSS\" action=\"#\" method=\"GET\">
			<h2>Enter Name:</h2>
			<input type=\"text\" name=\"name\">
			<input type=\"submit\" value=\"Submit\">
		</form>

		{$html}

	</div>
</div>
";

HtmlEcho( $page );

?>
