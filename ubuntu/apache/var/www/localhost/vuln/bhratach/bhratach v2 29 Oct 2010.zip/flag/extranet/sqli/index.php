<?php

define( 'WEB_PAGE_TO_ROOT', '../../../' );
require_once WEB_PAGE_TO_ROOT.'bhratach/includes/Page.inc.php';

PageStartup( array( 'authenticated', 'phpids' ) );

$page = PageNewGrab();
$page[ 'title' ] .= $page[ 'title_separator' ].'User ID Verification';
$page[ 'page_id' ] = 'sqli';

DatabaseConnect();

$vulnerabilityFile = 'low.php';


require_once WEB_PAGE_TO_ROOT."flag/extranet/sqli/source/{$vulnerabilityFile}";


$magicQuotesWarningHtml = '';

// Check if Magic Quotes are on or off
if( ini_get( 'magic_quotes_gpc' ) == true ) {
	$magicQuotesWarningHtml = "	<div class=\"warning\">This could be a red herring!!!</div>";
}

$page[ 'body' ] .= "
<div class=\"body_padded\">
	<h1>User Validation ID</h1>

	{$magicQuotesWarningHtml}

	<div class=\"vulnerable_code_area\">

		<h2>User ID:</h2>

		<form action=\"#\" method=\"GET\">
			<input type=\"text\" name=\"id\">
			<input type=\"submit\" name=\"Submit\" value=\"Submit\">
		</form>

		{$html}

	</div>


</div>
";

HtmlEcho( $page );

?>
